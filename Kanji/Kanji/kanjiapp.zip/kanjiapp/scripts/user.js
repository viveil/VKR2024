import { getMe } from "./api.js"


export const user =  {
        isAuth: false,
        token : '',
        profile : {}
}

