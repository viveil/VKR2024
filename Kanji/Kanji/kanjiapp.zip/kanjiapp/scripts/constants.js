
export const containerBlocks = document.querySelectorAll('.container__block')
export const container = document.querySelector('.container')
export const lessons = document.querySelectorAll('.container__base')